import type { Meta, StoryObj } from '@storybook/react'
import ${VARIABLE_NAME} from './${VARIABLE_NAME}'

const meta = {
   component: ${VARIABLE_NAME},
} satisfies Meta<typeof ${VARIABLE_NAME}>
export default meta;

type Story = StoryObj<typeof meta>

export const Default: Story = {}