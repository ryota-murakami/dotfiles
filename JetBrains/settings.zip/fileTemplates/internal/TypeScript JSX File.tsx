import type React from 'react'

interface Props {
}

export const ${NAME}: React.FC<Props> = () => {
    return <></>
})