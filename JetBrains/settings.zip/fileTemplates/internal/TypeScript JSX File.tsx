import type React from 'react'
import { memo } from 'react'

interface Props {
}

const ${NAME}: React.FC<Props> = memo(() => {
    return <></>
})
${NAME}.displayName = '${NAME}'

export default ${NAME}